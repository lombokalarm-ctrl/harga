## 1. Gambaran Produk
Umrah Costing Engine adalah aplikasi web SaaS untuk perusahaan travel umrah dan haji yang membantu menghitung HPP paket, harga jual, profitabilitas, simulasi okupansi, simulasi kurs, dan pembuatan proposal paket secara otomatis.
- Produk ditujukan untuk staf operasional, marketing, finance, manajemen, dan super admin agar seluruh proses costing paket berjalan cepat, terstandar, transparan, dan bisa diaudit.
- Nilai bisnis utama adalah mempercepat pembuatan paket, menurunkan risiko salah hitung, meningkatkan kontrol margin, dan memperjelas proyeksi profit sebelum paket dijual.

## 2. Fitur Inti

### 2.1 Peran Pengguna
| Peran | Metode Akses | Hak Akses Inti |
|------|--------------|----------------|
| Super Admin | Login email dan kata sandi | Kelola seluruh data master, user, margin default, kurs default, audit log, dan konfigurasi sistem |
| Finance | Login email dan kata sandi | Kelola biaya, komponen costing, kurs, validasi komponen keuangan, dan histori perubahan |
| Marketing | Login email dan kata sandi | Membuat simulasi paket, menghitung harga jual, membuat proposal, dan mengelola itinerary |
| Director | Login email dan kata sandi | Melihat dashboard profit, analisa paket, simulasi okupansi, dan indikator performa |

### 2.2 Modul Fungsional
1. **Autentikasi dan Otorisasi**: login, logout, profil, manajemen role berbasis permission.
2. **Dashboard Eksekutif**: kartu KPI, profit projection, occupancy analysis, cost composition, dan ringkasan paket aktif.
3. **Master Data Hotel**: CRUD hotel, filter kota dan bintang, upload foto hotel, status aktif/nonaktif.
4. **Master Data Maskapai**: CRUD maskapai, pengelolaan rute, harga tiket, bagasi, upload logo.
5. **Master Data Visa**: CRUD visa, harga per mata uang, masa berlaku.
6. **Master Data Transportasi**: CRUD layanan transportasi untuk bus, kereta Haramain, handling, dan VIP service.
7. **Master Data Pembimbing**: CRUD pembimbing, jenis peran, fee, dan kapasitas jamaah.
8. **Master Komponen Biaya**: CRUD komponen biaya per jamaah dan per grup, kategori biaya, dan default inclusion dalam paket.
9. **Manajemen Kurs**: input kurs USD dan SAR ke IDR, histori kurs, kurs aktif, dan recalculation paket.
10. **Paket Umrah Builder**: susun paket, pilih komponen, hotel, maskapai, visa, transportasi, pembimbing, target jamaah, simpan draft, dan duplikasi paket.
11. **Costing Engine**: hitung realtime total hotel, tiket, visa, biaya jamaah, biaya grup, total cost, HPP, dan rincian per komponen.
12. **Margin Calculator**: simulasi margin persentase dan target profit untuk menghasilkan harga jual dan profit per jamaah.
13. **Simulasi Okupansi**: tabel dan grafik untuk skenario jumlah jamaah 10 sampai 50 beserta HPP, harga jual, dan profit.
14. **Break Even Point**: hitung minimal jamaah, target aman, dan target ideal berdasarkan fixed cost dan profit per jamaah.
15. **Proposal Generator**: generate proposal paket berisi cover, hotel, maskapai, itinerary, harga, fasilitas, exclusions, syarat, PDF, dan print.
16. **Itinerary Builder**: susun itinerary drag and drop, template perjalanan, dan kustomisasi per hari.
17. **Komisi Agen**: kelola agen, fee per jamaah, persentase komisi, dan total komisi per paket.
18. **Audit Log**: catat login, tambah, edit, hapus, publish, perubahan kurs, dan aktivitas penting lainnya.

### 2.3 Detail Halaman
| Nama Halaman | Modul | Deskripsi Fitur |
|-------------|-------|-----------------|
| Login | Form autentikasi | Login berbasis email, validasi form, remember session, pesan error aman |
| Dashboard | KPI dan analitik | Menampilkan total cost, revenue, profit, margin, HPP, grafik profit projection, occupancy analysis, dan cost composition |
| Pengguna | Manajemen user | CRUD user, assign role, status aktif/nonaktif, reset kata sandi |
| Hotel | Master hotel | Tabel data, filter kota, filter bintang, upload foto, preview harga per malam, status |
| Maskapai | Master maskapai | Tabel data, kode maskapai, rute, harga tiket, mata uang, bagasi, upload logo |
| Visa | Master visa | CRUD visa, harga, mata uang, masa berlaku, pencarian |
| Transportasi | Master transportasi | CRUD layanan, kategori, harga, mata uang |
| Pembimbing | Master pembimbing | CRUD pembimbing, jenis, fee, maksimal jamaah |
| Komponen Biaya | Master biaya | CRUD kategori per jamaah/per grup, mata uang, default inclusion, pencarian dan filter |
| Kurs | Manajemen kurs | Input manual, histori, kurs aktif, trigger auto recalculation ke paket terkait |
| Paket Umrah | Daftar paket | Tabel paket, status draft/published, filter, duplikasi paket, akses ke builder |
| Builder Paket | Penyusunan paket | Form wizard atau panel builder untuk memilih hotel, maskapai, visa, transportasi, pembimbing, komponen biaya, dan target jamaah |
| Costing | Mesin perhitungan | Menampilkan rincian realtime semua rumus dan subtotal serta skenario biaya |
| Margin & BEP | Analisa profit | Input margin/target profit, hasil harga jual, profit per jamaah, profit total, BEP, target aman dan ideal |
| Simulasi Okupansi | Tabel dan grafik | Menampilkan skenario jumlah jamaah 10-50, HPP, harga jual, profit, dan visualisasi tren |
| Proposal | Generator proposal | Editor konten proposal, preview cover, fasilitas, exclusions, itinerary, export PDF dan print |
| Itinerary | Penyusun itinerary | Drag and drop per hari, pakai template 9 hari, 12 hari, plus Turki, Mesir, Dubai |
| Agen | Komisi agen | CRUD agen, fee per jamaah, persentase, kalkulasi total komisi per paket |
| Audit Log | Riwayat aktivitas | Tabel histori aktivitas, filter user, modul, waktu, dan jenis aksi |

## 3. Proses Inti
Pengguna login sesuai peran lalu mengelola data master yang menjadi acuan costing. Finance dan super admin memperbarui kurs dan komponen biaya, marketing menyusun paket melalui builder, sistem menghitung biaya secara realtime, lalu marketing atau manajemen melakukan simulasi margin, okupansi, dan BEP sebelum proposal dibuat dan dibagikan ke calon jamaah atau agen.

```mermaid
flowchart TD
    A["Pengguna Login"] --> B["Pilih Modul Sesuai Peran"]
    B --> C["Kelola Data Master"]
    B --> D["Kelola Kurs"]
    C --> E["Buat atau Duplikasi Paket"]
    D --> E
    E --> F["Sistem Hitung Costing Realtime"]
    F --> G["Simulasi Margin dan Harga Jual"]
    G --> H["Simulasi Okupansi dan BEP"]
    H --> I["Review Dashboard Analitik"]
    I --> J["Generate Proposal PDF atau Print"]
    J --> K["Audit Log Tercatat"]
```

## 4. Desain Antarmuka
### 4.1 Gaya Desain
- Tema visual: modern premium Islamic travel dengan nuansa korporat dan profesional.
- Warna utama: navy blue sebagai fondasi, gold sebagai aksen premium, putih dan abu terang untuk area konten.
- Gaya tombol: rounded-medium dengan state hover elegan, shadow halus, dan aksen gradien gold.
- Tipografi: heading serif atau display elegan untuk kesan premium, body sans-serif yang sangat mudah dibaca untuk aplikasi operasional.
- Tata letak: desktop-first dengan sidebar permanen di layar besar, top navigation ringkas, kartu KPI, tabel data rapih, dan panel analitik modular.
- Ikon: outline clean dengan sentuhan travel, finance, dan dashboard enterprise.

### 4.2 Ikhtisar Desain Halaman
| Nama Halaman | Modul | Elemen UI |
|-------------|-------|-----------|
| Dashboard | Kartu KPI | Kartu metrik premium, latar gradasi lembut, grafik Recharts, filter periode, summary cepat |
| Master Data | Tabel enterprise | TanStack Table, search, filter, pagination, bulk action ringan, modal form atau drawer form |
| Builder Paket | Form komposisi paket | Layout dua kolom, panel pilihan data master, summary sticky, badge status draft |
| Costing | Breakdown biaya | Tabel subtotal, panel formula, indikator kurs, perubahan realtime, warna aksen untuk profit dan risiko |
| Simulasi | Grafik dan tabel | Grafik garis/batang, highlight skenario aman, indikator warna untuk margin sehat |
| Proposal | Preview dokumen | Canvas atau preview halaman proposal, panel konfigurasi konten, tombol export PDF dan print |
| Itinerary | Drag and drop | Kartu hari perjalanan, blok aktivitas, template cepat, reorder intuitif |

### 4.3 Responsivitas
- Pendekatan desktop-first karena mayoritas penggunaan oleh staf kantor.
- Tetap adaptif di tablet dan mobile dengan sidebar collapse, kartu KPI stack vertikal, tabel horizontal scroll, dan form input yang tetap nyaman disentuh.
- Area simulasi dan grafik memiliki mode ringkas di layar kecil dengan prioritas pada angka inti dan CTA utama.

### 4.4 Panduan Pengalaman Visual
- Gunakan dark mode dan light mode dengan konsistensi warna brand navy-gold.
- Dashboard harus terasa eksklusif namun tetap fokus pada keterbacaan angka.
- Animasi digunakan seperlunya untuk transisi kartu, tabel, dan grafik tanpa mengganggu kerja operasional.
- Proposal PDF mengusung tampilan premium dengan cover yang menonjolkan citra perjalanan ibadah yang profesional.

## 5. Kebutuhan Non-Fungsional
- Keamanan autentikasi berbasis Laravel Sanctum dan kontrol akses berbasis role-permission.
- Semua perhitungan costing harus konsisten, dapat direproduksi, dan tercatat per versi paket.
- Pencarian, filter, pagination, dan sorting tersedia di modul master data dan audit log.
- Sistem harus mampu menangani banyak paket dan histori kurs tanpa penurunan performa signifikan.
- Aktivitas penting wajib tercatat untuk kebutuhan audit internal.
- Export PDF dan Excel harus konsisten dengan data perhitungan pada layar.

## 6. Kriteria Keberhasilan
- Pengguna dapat membangun paket umrah dari data master hingga proposal tanpa spreadsheet eksternal.
- HPP, harga jual, profit, okupansi, dan BEP tampil realtime dengan hasil yang akurat.
- Finance dan manajemen dapat melihat dampak perubahan kurs dan komponen biaya secara instan.
- Proposal paket dapat dihasilkan cepat dan siap dibagikan ke calon jamaah atau agen.
