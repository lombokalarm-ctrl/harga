## 1. Desain Arsitektur
Arsitektur menggunakan pemisahan frontend dan backend agar aplikasi mudah dikembangkan, diskalakan, dan dideploy. Backend Laravel menyediakan REST API dengan autentikasi Sanctum, business rule costing, audit trail, export, dan akses data PostgreSQL. Frontend React bertugas menangani pengalaman pengguna, builder paket, visualisasi analitik, dan preview proposal.

```mermaid
flowchart LR
    A["Browser Pengguna"] --> B["Frontend React + TypeScript"]
    B --> C["REST API Laravel 12"]
    C --> D["Service Layer"]
    D --> E["Repository Layer"]
    E --> F["PostgreSQL"]
    C --> G["Storage File"]
    C --> H["PDF / Excel Generator"]
    C --> I["Audit Log"]
```

## 2. Deskripsi Teknologi
- Frontend: React 18 + TypeScript + Vite + TailwindCSS + shadcn/ui + TanStack Table + Recharts + React Router + React Hook Form + Zod + Zustand atau TanStack Query untuk state data.
- Backend: Laravel 12 + PHP 8.4 + REST API + Laravel Sanctum + Form Request Validation + API Resource + Service Layer + Repository Pattern.
- Database: PostgreSQL 16.
- Penyimpanan file: local/public storage dengan abstraksi Laravel filesystem untuk foto hotel, logo maskapai, dan file proposal sementara.
- Export: DomPDF atau Snappy untuk PDF, Laravel Excel untuk Excel.
- Testing: PHPUnit/Pest untuk backend, React Testing Library/Vitest untuk frontend pada area kritis.
- Deployment: Docker untuk environment lokal, Ubuntu Server + Nginx + PHP-FPM + PostgreSQL untuk production.

## 3. Prinsip Arsitektur
- Gunakan clean architecture pragmatis: `Controller -> FormRequest -> Service -> Repository -> Model`.
- Semua logika bisnis costing, margin, okupansi, dan BEP dipusatkan di service agar konsisten di semua endpoint.
- Simpan snapshot perhitungan paket agar histori nilai tidak berubah tanpa jejak saat kurs atau master data berubah.
- Gunakan policy atau permission middleware untuk kontrol akses per role.
- Semua response API distandarkan melalui API Resource dan envelope response yang konsisten.
- Audit log dicatat pada semua aksi penting yang mengubah data atau status paket.

## 4. Definisi Rute Frontend
| Rute | Tujuan |
|------|--------|
| /login | Halaman login pengguna |
| /dashboard | Dashboard analitik utama |
| /users | Manajemen pengguna dan role |
| /master/hotels | Master data hotel |
| /master/airlines | Master data maskapai |
| /master/visas | Master data visa |
| /master/transports | Master data transportasi |
| /master/guides | Master data pembimbing |
| /master/cost-components | Master komponen biaya |
| /exchange-rates | Manajemen kurs dan histori kurs |
| /packages | Daftar paket umrah |
| /packages/new | Builder paket baru |
| /packages/:id | Detail paket |
| /packages/:id/edit | Edit paket |
| /packages/:id/costing | Tampilan costing engine |
| /packages/:id/simulations | Margin, okupansi, dan BEP |
| /packages/:id/proposal | Preview dan generator proposal |
| /packages/:id/itinerary | Builder itinerary |
| /agents | Manajemen komisi agen |
| /audit-logs | Audit log sistem |
| /profile | Profil pengguna |

## 5. Definisi API
### 5.1 Pola Endpoint
- Prefix API: `/api/v1`
- Auth: Laravel Sanctum dengan cookie/session SPA atau token personal sesuai skenario.
- Format response sukses:

```ts
type ApiResponse<T> = {
  success: boolean;
  message: string;
  data: T;
  meta?: {
    page?: number;
    per_page?: number;
    total?: number;
  };
};
```

- Format response error:

```ts
type ApiError = {
  success: false;
  message: string;
  errors?: Record<string, string[]>;
};
```

### 5.2 Endpoint Autentikasi
| Method | Endpoint | Tujuan |
|--------|----------|--------|
| POST | /auth/login | Login pengguna |
| POST | /auth/logout | Logout pengguna |
| GET | /auth/me | Ambil profil dan permission |

### 5.3 Endpoint Master Data
| Method | Endpoint | Tujuan |
|--------|----------|--------|
| GET | /hotels | List hotel dengan filter, search, pagination |
| POST | /hotels | Tambah hotel |
| GET | /hotels/{id} | Detail hotel |
| PUT | /hotels/{id} | Ubah hotel |
| DELETE | /hotels/{id} | Hapus hotel |
| POST | /hotels/{id}/photo | Upload foto hotel |
| GET | /airlines | List maskapai |
| POST | /airlines | Tambah maskapai |
| PUT | /airlines/{id} | Ubah maskapai |
| DELETE | /airlines/{id} | Hapus maskapai |
| POST | /airlines/{id}/logo | Upload logo maskapai |
| GET | /visas | List visa |
| POST | /visas | Tambah visa |
| PUT | /visas/{id} | Ubah visa |
| DELETE | /visas/{id} | Hapus visa |
| GET | /transports | List transportasi |
| POST | /transports | Tambah transportasi |
| PUT | /transports/{id} | Ubah transportasi |
| DELETE | /transports/{id} | Hapus transportasi |
| GET | /guides | List pembimbing |
| POST | /guides | Tambah pembimbing |
| PUT | /guides/{id} | Ubah pembimbing |
| DELETE | /guides/{id} | Hapus pembimbing |
| GET | /cost-components | List komponen biaya |
| POST | /cost-components | Tambah komponen biaya |
| PUT | /cost-components/{id} | Ubah komponen biaya |
| DELETE | /cost-components/{id} | Hapus komponen biaya |
| GET | /agents | List agen |
| POST | /agents | Tambah agen |
| PUT | /agents/{id} | Ubah agen |
| DELETE | /agents/{id} | Hapus agen |

### 5.4 Endpoint Kurs
| Method | Endpoint | Tujuan |
|--------|----------|--------|
| GET | /exchange-rates | List kurs dan histori |
| POST | /exchange-rates | Tambah kurs baru |
| GET | /exchange-rates/current | Kurs aktif |
| POST | /exchange-rates/recalculate | Recalculate paket terdampak |

### 5.5 Endpoint Paket dan Costing
| Method | Endpoint | Tujuan |
|--------|----------|--------|
| GET | /packages | List paket |
| POST | /packages | Buat paket draft |
| GET | /packages/{id} | Detail paket |
| PUT | /packages/{id} | Ubah paket |
| POST | /packages/{id}/duplicate | Duplikasi paket |
| POST | /packages/{id}/publish | Publish paket |
| GET | /packages/{id}/costing | Ambil perhitungan costing realtime |
| POST | /packages/{id}/costing/recalculate | Hitung ulang costing |
| POST | /packages/{id}/simulations/margin | Hitung harga jual dan profit |
| POST | /packages/{id}/simulations/occupancy | Simulasi okupansi |
| POST | /packages/{id}/simulations/bep | Hitung break even point |
| GET | /packages/{id}/proposal | Data proposal |
| POST | /packages/{id}/proposal/pdf | Generate PDF proposal |
| GET | /packages/{id}/proposal/print | Render print view |
| GET | /packages/{id}/itinerary | Ambil itinerary |
| PUT | /packages/{id}/itinerary | Simpan itinerary |

### 5.6 Endpoint Dashboard dan Audit
| Method | Endpoint | Tujuan |
|--------|----------|--------|
| GET | /dashboard/summary | Ringkasan KPI |
| GET | /dashboard/profit-projection | Data grafik proyeksi profit |
| GET | /dashboard/occupancy-analysis | Data analisa okupansi |
| GET | /dashboard/cost-composition | Data komposisi biaya |
| GET | /audit-logs | List audit log |

## 6. Diagram Arsitektur Server
```mermaid
flowchart TD
    A["API Route"] --> B["Controller"]
    B --> C["Form Request Validation"]
    C --> D["Service"]
    D --> E["Repository"]
    E --> F["Eloquent Model"]
    F --> G["PostgreSQL"]
    D --> H["Audit Log Service"]
    D --> I["Exchange Rate Service"]
    D --> J["PDF / Excel Export Service"]
```

## 7. Model Data
### 7.1 Definisi ERD
```mermaid
erDiagram
    roles ||--o{ users : "memiliki"
    users ||--o{ audit_logs : "mencatat"
    hotels ||--o{ hotel_photos : "memiliki"
    airlines ||--o{ airline_logos : "memiliki"
    package_umrahs ||--o{ package_hotels : "memiliki"
    hotels ||--o{ package_hotels : "dipakai"
    package_umrahs }o--|| airlines : "memilih"
    package_umrahs }o--|| visas : "memilih"
    package_umrahs ||--o{ package_transports : "memiliki"
    transports ||--o{ package_transports : "dipakai"
    package_umrahs ||--o{ package_guides : "memiliki"
    guides ||--o{ package_guides : "dipakai"
    package_umrahs ||--o{ package_cost_components : "memiliki"
    cost_components ||--o{ package_cost_components : "dipakai"
    package_umrahs ||--o{ itineraries : "memiliki"
    package_umrahs ||--o{ package_snapshots : "memiliki"
    package_umrahs ||--o{ package_proposals : "memiliki"
    agents ||--o{ package_agent_commissions : "memiliki"
    package_umrahs ||--o{ package_agent_commissions : "menghitung"
    exchange_rates ||--o{ package_snapshots : "dipakai"
```

### 7.2 Daftar Tabel Inti
| Tabel | Fungsi |
|------|--------|
| roles | Referensi role sistem |
| users | Akun pengguna |
| hotels | Master hotel |
| hotel_photos | File foto hotel |
| airlines | Master maskapai |
| airline_logos | File logo maskapai |
| visas | Master visa |
| transports | Master transportasi |
| guides | Master pembimbing |
| cost_components | Master komponen biaya |
| exchange_rates | Histori dan kurs aktif |
| package_umrahs | Header paket umrah |
| package_hotels | Relasi hotel Makkah dan Madinah per paket |
| package_transports | Relasi transportasi per paket |
| package_guides | Relasi pembimbing per paket |
| package_cost_components | Biaya terpilih per paket |
| itineraries | Detail itinerary per hari |
| package_snapshots | Snapshot hasil perhitungan, kurs, dan nilai simulasi |
| package_proposals | Metadata proposal dan versi PDF |
| agents | Master agen |
| package_agent_commissions | Perhitungan komisi agen per paket |
| audit_logs | Jejak aktivitas sistem |

### 7.3 Definisi Struktur Data Utama
```ts
type CurrencyCode = 'IDR' | 'USD' | 'SAR';

type PackageStatus = 'draft' | 'published' | 'archived';

type CostComponentType = 'per_jamaah' | 'per_grup';

type GuideType = 'muthawwif' | 'tour_leader' | 'ustadz';

type TransportCategory = 'bus' | 'kereta_haramain' | 'handling' | 'vip_service';

interface UmrahPackagePayload {
  nama_paket: string;
  durasi_hari: number;
  target_jamaah: number;
  hotel_makkah_id: number;
  hotel_madinah_id: number;
  airline_id: number;
  visa_id: number;
  transport_ids: number[];
  guide_ids: number[];
  cost_component_ids: number[];
  default_margin_percent?: number;
  target_profit_total?: number;
}

interface CostingResult {
  total_hotel: number;
  total_tiket: number;
  total_visa: number;
  total_biaya_jamaah: number;
  total_biaya_grup: number;
  total_cost: number;
  hpp_per_jamaah: number;
  harga_jual_per_jamaah?: number;
  profit_per_jamaah?: number;
  profit_total?: number;
  break_even_jamaah?: number;
}
```

### 7.4 DDL PostgreSQL
```sql
CREATE TABLE roles (
    id BIGSERIAL PRIMARY KEY,
    name VARCHAR(50) UNIQUE NOT NULL,
    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL
);

CREATE TABLE users (
    id BIGSERIAL PRIMARY KEY,
    role_id BIGINT NOT NULL REFERENCES roles(id),
    name VARCHAR(120) NOT NULL,
    email VARCHAR(150) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL
);

CREATE TABLE hotels (
    id BIGSERIAL PRIMARY KEY,
    nama_hotel VARCHAR(150) NOT NULL,
    kota VARCHAR(80) NOT NULL,
    kategori_bintang SMALLINT NOT NULL,
    alamat TEXT,
    jarak_ke_masjid INTEGER,
    harga_per_malam NUMERIC(18,2) NOT NULL,
    mata_uang VARCHAR(3) NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'active',
    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL
);

CREATE TABLE airlines (
    id BIGSERIAL PRIMARY KEY,
    nama_maskapai VARCHAR(150) NOT NULL,
    kode_maskapai VARCHAR(10) NOT NULL,
    rute VARCHAR(255),
    harga_tiket NUMERIC(18,2) NOT NULL,
    mata_uang VARCHAR(3) NOT NULL,
    bagasi VARCHAR(100),
    status VARCHAR(20) NOT NULL DEFAULT 'active',
    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL
);

CREATE TABLE visas (
    id BIGSERIAL PRIMARY KEY,
    nama_visa VARCHAR(120) NOT NULL,
    harga NUMERIC(18,2) NOT NULL,
    mata_uang VARCHAR(3) NOT NULL,
    masa_berlaku INTEGER NOT NULL,
    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL
);

CREATE TABLE transports (
    id BIGSERIAL PRIMARY KEY,
    nama_layanan VARCHAR(150) NOT NULL,
    kategori VARCHAR(50) NOT NULL,
    harga NUMERIC(18,2) NOT NULL,
    mata_uang VARCHAR(3) NOT NULL,
    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL
);

CREATE TABLE guides (
    id BIGSERIAL PRIMARY KEY,
    nama VARCHAR(150) NOT NULL,
    jabatan VARCHAR(100),
    jenis VARCHAR(50) NOT NULL,
    fee NUMERIC(18,2) NOT NULL,
    maksimal_jamaah INTEGER NOT NULL,
    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL
);

CREATE TABLE cost_components (
    id BIGSERIAL PRIMARY KEY,
    nama VARCHAR(150) NOT NULL,
    kategori VARCHAR(20) NOT NULL,
    harga NUMERIC(18,2) NOT NULL,
    mata_uang VARCHAR(3) NOT NULL,
    is_default BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL
);

CREATE TABLE exchange_rates (
    id BIGSERIAL PRIMARY KEY,
    usd_to_idr NUMERIC(18,4) NOT NULL,
    sar_to_idr NUMERIC(18,4) NOT NULL,
    effective_at TIMESTAMP NOT NULL,
    is_active BOOLEAN NOT NULL DEFAULT FALSE,
    created_by BIGINT NULL REFERENCES users(id),
    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL
);

CREATE TABLE package_umrahs (
    id BIGSERIAL PRIMARY KEY,
    nama_paket VARCHAR(180) NOT NULL,
    durasi_hari INTEGER NOT NULL,
    target_jamaah INTEGER NOT NULL,
    airline_id BIGINT NOT NULL REFERENCES airlines(id),
    visa_id BIGINT NOT NULL REFERENCES visas(id),
    status VARCHAR(20) NOT NULL DEFAULT 'draft',
    default_margin_percent NUMERIC(8,2) NULL,
    target_profit_total NUMERIC(18,2) NULL,
    created_by BIGINT NULL REFERENCES users(id),
    updated_by BIGINT NULL REFERENCES users(id),
    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL
);

CREATE TABLE package_snapshots (
    id BIGSERIAL PRIMARY KEY,
    package_id BIGINT NOT NULL REFERENCES package_umrahs(id) ON DELETE CASCADE,
    exchange_rate_id BIGINT NULL REFERENCES exchange_rates(id),
    payload_json JSONB NOT NULL,
    total_cost NUMERIC(18,2) NOT NULL,
    hpp_per_jamaah NUMERIC(18,2) NOT NULL,
    harga_jual_per_jamaah NUMERIC(18,2) NULL,
    profit_total NUMERIC(18,2) NULL,
    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL
);

CREATE TABLE audit_logs (
    id BIGSERIAL PRIMARY KEY,
    user_id BIGINT NULL REFERENCES users(id),
    module VARCHAR(100) NOT NULL,
    action VARCHAR(100) NOT NULL,
    auditable_type VARCHAR(150) NULL,
    auditable_id BIGINT NULL,
    description TEXT NULL,
    metadata JSONB NULL,
    created_at TIMESTAMP NULL
);

CREATE INDEX idx_hotels_kota ON hotels(kota);
CREATE INDEX idx_hotels_bintang ON hotels(kategori_bintang);
CREATE INDEX idx_packages_status ON package_umrahs(status);
CREATE INDEX idx_exchange_rates_active ON exchange_rates(is_active);
CREATE INDEX idx_audit_logs_module ON audit_logs(module);
```

## 8. Strategi Modul Backend Laravel
- `app/Domain/*`: entity value object dan kontrak domain bila diperlukan.
- `app/Repositories/*`: abstraksi akses data per modul.
- `app/Services/*`: costing engine, margin, occupancy, BEP, proposal, exchange rate recalculation, audit log.
- `app/Http/Controllers/Api/V1/*`: controller REST per modul.
- `app/Http/Requests/*`: validasi input granular.
- `app/Http/Resources/*`: serialisasi response.
- `app/Policies/*`: otorisasi per resource.
- `app/Jobs/*`: generate PDF asynchronous, recalculation massal, export Excel.

## 9. Strategi Frontend React
- Struktur fitur per domain: `features/hotels`, `features/packages`, `features/simulations`, `features/dashboard`.
- Gunakan layout shell dengan sidebar, top bar, breadcrumb, dan theme toggle.
- Komponen data-intensive menggunakan TanStack Table untuk filter, search, pagination, sorting, dan column visibility.
- Grafik menggunakan Recharts dengan skema warna brand yang konsisten.
- Form builder menggunakan React Hook Form + Zod, termasuk nested form untuk komponen paket.
- State data server menggunakan TanStack Query agar caching dan invalidasi mudah dikelola.

## 10. Rumus Inti Costing
- Total Hotel = `(harga hotel makkah x malam makkah x jumlah kamar) + (harga hotel madinah x malam madinah x jumlah kamar)`
- Total Tiket = `harga tiket x jumlah jamaah`
- Total Visa = `harga visa x jumlah jamaah`
- Total Biaya Jamaah = `jumlah seluruh komponen kategori per_jamaah x jumlah jamaah`
- Total Biaya Grup = `jumlah seluruh komponen kategori per_grup`
- Total Cost = `total hotel + total tiket + total visa + total biaya jamaah + total biaya grup + total komisi agen`
- HPP = `total cost / jumlah jamaah`
- Harga Jual per Jamaah = `hpp + (hpp x margin%)` atau berdasarkan `target profit / jumlah jamaah`
- Profit Total = `(harga jual per jamaah x jumlah jamaah) - total cost`
- Profit per Jamaah = `harga jual per jamaah - hpp`
- BEP Jamaah = `fixed cost / profit per jamaah`

## 11. Validasi dan Aturan Bisnis
- Paket tidak dapat dipublish jika hotel, maskapai, visa, target jamaah, dan snapshot costing belum valid.
- Kurs aktif tunggal per waktu; saat kurs baru diaktifkan, sistem menyimpan histori dan menandai paket terdampak perlu recalculation.
- Komponen biaya mendukung mata uang IDR, USD, dan SAR; konversi selalu menggunakan kurs snapshot aktif saat perhitungan.
- Pembimbing dapat divalidasi terhadap maksimal jamaah untuk memberikan rekomendasi jumlah guide.
- Semua perubahan master yang memengaruhi paket harus masuk audit log.

## 12. Strategi Testing
- Unit test service costing untuk seluruh rumus utama dan skenario kurs.
- Feature test endpoint autentikasi, CRUD master data, paket, simulasi, dan export.
- Test validasi authorization untuk role Super Admin, Finance, Marketing, dan Director.
- Frontend test untuk halaman costing, simulasi okupansi, dan builder paket pada interaksi kritis.

## 13. Strategi Docker dan Deployment
- Docker Compose lokal berisi `nginx`, `php-fpm`, `postgres`, dan `node` untuk build frontend.
- Production Ubuntu menggunakan Nginx reverse proxy, PHP-FPM 8.4, PostgreSQL, Supervisor untuk queue, dan cron Laravel scheduler.
- File upload disimpan pada volume persisten; backup database dan storage dijadwalkan berkala.
- Environment dipisah untuk `APP_ENV`, kredensial database, queue, cache, dan mail.

## 14. Tahapan Implementasi
1. Inisialisasi monorepo atau struktur terpisah `backend` dan `frontend`.
2. Siapkan autentikasi, role-permission, dan layout dashboard.
3. Implementasikan seluruh master data dan manajemen kurs.
4. Bangun paket builder, costing engine, margin, okupansi, dan BEP.
5. Tambahkan proposal generator, itinerary builder, komisi agen, dan audit log.
6. Lengkapi testing, Docker, seeder dummy, dan panduan deployment.
